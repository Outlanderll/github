package com.lmd.blog.service;

import com.lmd.blog.po.User;

public interface UserService {

    User checkUser(String username, String password);
}
